<a href="/">

    <img  class="w-16 h-16" src="{{asset('/assets/img/logo.svg')}}" alt="">
</a>
