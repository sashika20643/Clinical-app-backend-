<img class="w-16 h-16" src="<?php echo e(asset('/assets/img/logo.svg')); ?>" alt="">
<?php /**PATH E:\projects\laravel\hospital\resources\views/components/application-mark.blade.php ENDPATH**/ ?>