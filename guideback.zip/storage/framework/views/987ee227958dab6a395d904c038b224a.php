<a href="/">

    <img  class="w-16 h-16" src="<?php echo e(asset('/assets/img/logo.svg')); ?>" alt="">
</a>
<?php /**PATH E:\projects\laravel\hospital\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>