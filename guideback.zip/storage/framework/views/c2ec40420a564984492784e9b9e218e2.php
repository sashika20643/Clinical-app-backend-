<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="card-body px-0 pt-0 pb-2">
        <div class="table-responsive p-0">
          <table class="table align-items-center mb-0">
            <thead>
              <tr>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">ID</th>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">message Name</th>
                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Message</th>
                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Date</th>

              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mesages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td>
                      <p class="text-xs font-weight-bold mb-0"><?php echo e(($message->id)); ?></p>

                    </td>
                    <td class="align-middle text-center text-sm">
                      <span class="text-secondary text-xs font-weight-bold"><?php echo e($message->name); ?></span>
                    </td>
                    <td class="align-middle text-center">
                      <span class="text-secondary text-xs font-weight-bold"><?php echo e($message->message); ?></span>
                    </td>
                    <td class="align-middle text-center">
                        <span class="badge badge-sm bg-gradient-success"><?php echo e($message->created_at); ?></span>
                      </td>


                  </tr>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
          </table>
        </div>
      </div>


</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\laravel\hospital\resources\views/Admin/message.blade.php ENDPATH**/ ?>